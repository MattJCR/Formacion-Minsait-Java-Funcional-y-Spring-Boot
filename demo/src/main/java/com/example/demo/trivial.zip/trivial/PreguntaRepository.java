package com.example.demo.trivial;

import org.springframework.data.repository.CrudRepository;

public interface PreguntaRepository extends CrudRepository<PreguntaEntity, Long>{
    
}
